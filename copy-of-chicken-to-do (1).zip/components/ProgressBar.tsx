import React from 'react';

interface ProgressBarProps {
  progress: number; // 0 to 100
  label?: string;
  subLabel?: string;
  color?: string;
  height?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ 
  progress, 
  label, 
  subLabel,
  color = '#22c55e',
  height = 'h-6'
}) => {
  return (
    <div className="w-full">
      {(label || subLabel) && (
          <div className="flex justify-between mb-1 text-lg font-bold">
              <span>{label}</span>
              <span>{subLabel}</span>
          </div>
      )}
      <div className={`w-full border-4 border-black bg-white relative rounded-lg overflow-hidden ${height}`}>
        <div 
          className="h-full transition-all duration-500 ease-out border-r-4 border-black/20"
          style={{ width: `${Math.min(100, Math.max(0, progress))}%`, backgroundColor: color }}
        />
        {/* Shine effect */}
        <div className="absolute top-1 left-1 right-1 h-[30%] bg-white opacity-30 rounded-full" />
      </div>
    </div>
  );
};
