import React from 'react';

interface PixelButtonProps {
  children: React.ReactNode;
  onClick: () => void;
  variant?: 'primary' | 'secondary' | 'danger';
  className?: string;
  fullWidth?: boolean;
}

export const PixelButton: React.FC<PixelButtonProps> = ({ 
  children, 
  onClick, 
  variant = 'primary', 
  className = '',
  fullWidth = true
}) => {
  const baseStyles = "relative font-bold text-3xl py-4 px-6 rounded-3xl border-[6px] transition-transform active:scale-95 shadow-lg select-none";
  
  const variants = {
    primary: "bg-[#F4D096] border-black text-white text-shadow-outline hover:bg-[#ffe0a3]", // Beige/Tan from image
    secondary: "bg-[#60A5FA] border-black text-white hover:bg-[#93C5FD]",
    danger: "bg-[#EF4444] border-black text-white hover:bg-[#F87171]"
  };

  // Custom text outline effect for that cartoony look
  const textShadow = {
    textShadow: '2px 2px 0 #000, -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000'
  };

  return (
    <button 
      onClick={onClick}
      className={`${baseStyles} ${variants[variant]} ${fullWidth ? 'w-full' : ''} ${className}`}
      style={textShadow}
    >
      {children}
    </button>
  );
};
