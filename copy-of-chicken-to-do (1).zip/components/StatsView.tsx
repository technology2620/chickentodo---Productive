import React from 'react';
import { UserStats, Badge } from '../types';
import { BADGES, MOCK_LEADERBOARD, getNextLevelThreshold, getPointsForCurrentLevel } from '../services/gamification';
import { ProgressBar } from './ProgressBar';
import { ArrowLeft, Trophy, Medal, Lock } from 'lucide-react';

interface StatsViewProps {
  stats: UserStats;
  onBack: () => void;
}

export const StatsView: React.FC<StatsViewProps> = ({ stats, onBack }) => {
  // Level Calculation
  const nextLevelPoints = getNextLevelThreshold(stats.level);
  const prevLevelPoints = getPointsForCurrentLevel(stats.level);
  const levelProgress = ((stats.points - prevLevelPoints) / (nextLevelPoints - prevLevelPoints)) * 100;

  // Chart Data (Last 7 Days)
  const getLast7Days = () => {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      days.push({
        label: d.toLocaleDateString('en-US', { weekday: 'narrow' }),
        count: stats.history[dateStr] || 0
      });
    }
    return days;
  };
  const weeklyData = getLast7Days();
  const maxTasks = Math.max(...weeklyData.map(d => d.count), 5); // Scale max

  // Leaderboard Integration
  const leaderboard = [...MOCK_LEADERBOARD, { name: 'YOU', points: stats.points }]
    .sort((a, b) => b.points - a.points)
    .slice(0, 5);

  return (
    <div className="flex flex-col h-full w-full max-w-lg mx-auto pt-4 px-4 pb-32 overflow-hidden">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <button onClick={onBack} className="bg-white border-2 border-black p-2 rounded hover:bg-gray-100">
            <ArrowLeft size={24} />
        </button>
        <h2 className="text-4xl text-white drop-shadow-[3px_3px_0_#000]">Stats & Rewards</h2>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 overflow-y-auto pixel-scrollbar space-y-6 pr-2">
        {/* Level Card */}
        <div className="bg-[#F4D096] border-4 border-black p-4 rounded-2xl shadow-[4px_4px_0_rgba(0,0,0,0.2)]">
            <div className="flex items-center justify-between mb-2">
                <span className="text-3xl font-bold">Level {stats.level}</span>
                <span className="text-xl">{stats.points} XP</span>
            </div>
            <ProgressBar 
                progress={levelProgress} 
                subLabel={`${Math.floor(nextLevelPoints - stats.points)} XP to next level`}
                color="#60A5FA"
            />
        </div>

        {/* Weekly Progress Chart */}
        <div className="bg-white border-4 border-black p-4 rounded-2xl shadow-[4px_4px_0_rgba(0,0,0,0.2)]">
            <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Medal className="text-yellow-500" /> Weekly Activity
            </h3>
            <div className="flex items-end justify-between h-32 gap-2">
                {weeklyData.map((day, idx) => (
                    <div key={idx} className="flex flex-col items-center flex-1 h-full justify-end group">
                        <div className="text-xs mb-1 font-bold opacity-0 group-hover:opacity-100 transition-opacity absolute -mt-6">
                            {day.count}
                        </div>
                        <div 
                            className="w-full bg-[#10B981] border-2 border-black rounded-t-sm transition-all duration-500"
                            style={{ height: `${(day.count / maxTasks) * 100}%`, minHeight: '4px' }}
                        />
                        <span className="text-sm font-bold mt-1">{day.label}</span>
                    </div>
                ))}
            </div>
        </div>

        {/* Badges Grid */}
        <div className="bg-white border-4 border-black p-4 rounded-2xl shadow-[4px_4px_0_rgba(0,0,0,0.2)]">
            <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Trophy className="text-yellow-500" /> Badges
            </h3>
            <div className="grid grid-cols-3 gap-3">
                {BADGES.map(badge => {
                    const isUnlocked = stats.unlockedBadges.includes(badge.id);
                    return (
                        <div key={badge.id} className={`flex flex-col items-center text-center p-2 rounded-xl border-2 ${isUnlocked ? 'bg-yellow-50 border-yellow-500' : 'bg-gray-100 border-gray-300'}`}>
                            <div className="text-3xl mb-1">
                                {isUnlocked ? badge.icon : <Lock size={24} className="text-gray-400 mx-auto" />}
                            </div>
                            <span className={`text-sm font-bold leading-none ${isUnlocked ? 'text-black' : 'text-gray-400'}`}>
                                {badge.name}
                            </span>
                        </div>
                    );
                })}
            </div>
        </div>

        {/* Leaderboard */}
        <div className="bg-white border-4 border-black p-4 rounded-2xl shadow-[4px_4px_0_rgba(0,0,0,0.2)]">
            <h3 className="text-2xl font-bold mb-4">Top Chickens</h3>
            <div className="space-y-2">
                {leaderboard.map((entry, idx) => (
                    <div 
                        key={idx} 
                        className={`flex justify-between items-center p-2 border-2 rounded-lg ${entry.name === 'YOU' ? 'bg-yellow-100 border-yellow-500 scale-105 shadow-md' : 'border-gray-200'}`}
                    >
                        <div className="flex items-center gap-3">
                            <span className="font-bold w-6 text-center text-xl text-gray-500">#{idx + 1}</span>
                            <span className="font-bold text-lg">{entry.name}</span>
                        </div>
                        <span className="font-bold text-gray-600">{entry.points} pts</span>
                    </div>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};
