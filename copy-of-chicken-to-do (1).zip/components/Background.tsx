import React from 'react';
import { BgTheme } from '../types';

interface BackgroundProps {
    theme?: BgTheme;
}

export const Background: React.FC<BackgroundProps> = ({ theme = 'beach' }) => {
  
  const renderBeach = () => (
    <>
      <div className="absolute inset-0 bg-gradient-to-b from-sky-300 to-sky-400" />
      {/* Ocean */}
      <div className="absolute bottom-[25%] w-full h-[45%] bg-[#1e40af] border-t-4 border-[#172554]" />
      <div className="absolute bottom-[20%] w-full h-[10%] bg-[#2563eb] opacity-80" />
      <div className="absolute bottom-[18%] w-full h-[5%] bg-[#3b82f6] opacity-60" />
      <div className="absolute bottom-0 w-full h-[20%] bg-[#FDE68A] border-t-4 border-[#FCD34D]" />
    </>
  );

  const renderPark = () => (
    <>
      <div className="absolute inset-0 bg-sky-200" />
      {/* Trees Background */}
      <div className="absolute bottom-[30%] left-0 w-32 h-64 bg-green-700 rounded-t-full" />
      <div className="absolute bottom-[30%] right-0 w-48 h-56 bg-green-700 rounded-t-full" />
      <div className="absolute bottom-0 w-full h-[35%] bg-[#4ADE80] border-t-4 border-[#22C55E]" />
      <div className="absolute bottom-[32%] w-full h-4 bg-[#166534] opacity-20" />
    </>
  );

  const renderSky = () => (
    <>
      <div className="absolute inset-0 bg-gradient-to-b from-[#0EA5E9] to-[#BAE6FD]" />
      <div className="absolute top-[10%] left-[20%] w-64 h-32 bg-white rounded-full opacity-60 blur-xl" />
      <div className="absolute bottom-[10%] right-[10%] w-96 h-48 bg-white rounded-full opacity-40 blur-xl" />
    </>
  );
  
  const renderPlains = () => (
     <>
      <div className="absolute inset-0 bg-[#7DD3FC]" />
      <div className="absolute bottom-[20%] w-full h-[40%] bg-green-600 rounded-t-[100%]" />
      <div className="absolute bottom-0 w-full h-[30%] bg-[#22C55E]" />
     </>
  );

  return (
    <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
      {theme === 'beach' && renderBeach()}
      {theme === 'park' && renderPark()}
      {theme === 'sky' && renderSky()}
      {theme === 'plains' && renderPlains()}
      
      {/* Common Clouds */}
      <div className="absolute top-[10%] left-[-10%] w-40 h-20 bg-white rounded-full opacity-90 animate-pulse" />
      <div className="absolute top-[15%] right-[-5%] w-60 h-24 bg-white rounded-full opacity-80" />
    </div>
  );
};
