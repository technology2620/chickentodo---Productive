import React from 'react';

export const Boat = ({ className = "" }: { className?: string }) => (
    <svg viewBox="0 0 32 32" className={`w-full h-full drop-shadow-md ${className}`} shapeRendering="crispEdges">
        {/* Hull */}
        <rect x="4" y="20" width="24" height="6" fill="#8B4513" />
        <rect x="2" y="18" width="2" height="4" fill="#8B4513" />
        <rect x="28" y="18" width="2" height="4" fill="#8B4513" />
        {/* Cabin */}
        <rect x="8" y="14" width="10" height="6" fill="#F3F4F6" />
        <rect x="10" y="16" width="4" height="2" fill="#60A5FA" />
        {/* Mast/Flag */}
        <rect x="20" y="10" width="1" height="10" fill="#000" />
        <rect x="21" y="11" width="4" height="3" fill="#EF4444" />
    </svg>
);

export const Rocket = ({ className = "" }: { className?: string }) => (
    <svg viewBox="0 0 32 32" className={`w-full h-full drop-shadow-xl ${className}`} shapeRendering="crispEdges">
        {/* Body */}
        <rect x="12" y="8" width="8" height="16" fill="#E5E7EB" />
        {/* Nose */}
        <rect x="14" y="4" width="4" height="4" fill="#DC2626" />
        {/* Fins */}
        <rect x="10" y="20" width="2" height="6" fill="#DC2626" />
        <rect x="20" y="20" width="2" height="6" fill="#DC2626" />
        {/* Window */}
        <rect x="14" y="12" width="4" height="4" fill="#60A5FA" />
        {/* Flame */}
        <rect x="14" y="24" width="4" height="6" fill="#F59E0B" className="animate-pulse" />
        <rect x="15" y="26" width="2" height="3" fill="#FEF08A" />
    </svg>
);

export const FriedChicken = ({ className = "" }: { className?: string }) => (
    <svg viewBox="0 0 32 32" className={`w-full h-full drop-shadow-xl ${className}`} shapeRendering="crispEdges">
        {/* Bucket */}
        <rect x="8" y="14" width="16" height="14" fill="#DC2626" />
        <rect x="8" y="14" width="16" height="2" fill="#F3F4F6" />
        <rect x="8" y="26" width="16" height="2" fill="#F3F4F6" />
        {/* Chicken Legs */}
        <rect x="10" y="8" width="4" height="8" fill="#D97706" />
        <rect x="11" y="6" width="2" height="2" fill="#FDE68A" /> {/* Bone */}
        
        <rect x="18" y="9" width="4" height="8" fill="#D97706" />
        <rect x="19" y="7" width="2" height="2" fill="#FDE68A" />
        
        <rect x="14" y="10" width="4" height="8" fill="#D97706" />
        <rect x="15" y="8" width="2" height="2" fill="#FDE68A" />
    </svg>
);
