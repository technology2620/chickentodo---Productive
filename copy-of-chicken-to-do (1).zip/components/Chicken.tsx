import React, { useEffect, useState } from 'react';
import { ChickenSkin } from '../types';

interface ChickenProps {
  talking?: boolean;
  skin?: ChickenSkin;
  onClick?: () => void;
  className?: string;
}

export const Chicken: React.FC<ChickenProps> = ({ talking = false, skin = 'brownie', onClick, className = '' }) => {
  const [bounce, setBounce] = useState(false);

  useEffect(() => {
    if (talking) {
      const interval = setInterval(() => {
        setBounce(prev => !prev);
      }, 200);
      return () => clearInterval(interval);
    } else {
      setBounce(false);
    }
  }, [talking]);

  // Skin Colors
  const colors = {
    brownie: { main: '#8B4513', shadow: '#A0522D', highlight: '#CD853F' },
    generic: { main: '#F3F4F6', shadow: '#D1D5DB', highlight: '#FFFFFF' },
    bluejay: { main: '#2563EB', shadow: '#1D4ED8', highlight: '#60A5FA' },
    spicy:   { main: '#DC2626', shadow: '#B91C1C', highlight: '#EF4444' },
    lemon:   { main: '#FBBF24', shadow: '#D97706', highlight: '#FCD34D' },
  };

  const c = colors[skin];

  return (
    <div 
      className={`relative cursor-pointer transition-transform duration-200 ${bounce ? '-translate-y-2' : 'translate-y-0'} ${className}`}
      onClick={onClick}
      style={{ width: '120px', height: '120px' }}
    >
      <svg viewBox="0 0 32 32" className="w-full h-full drop-shadow-xl" shapeRendering="crispEdges">
        {/* Feet */}
        <rect x="12" y="29" width="3" height="1" fill="#D97706" />
        <rect x="18" y="29" width="3" height="1" fill="#D97706" />
        <rect x="13" y="28" width="1" height="1" fill="#D97706" />
        <rect x="19" y="28" width="1" height="1" fill="#D97706" />

        {/* Body Main */}
        <rect x="10" y="14" width="14" height="14" fill={c.main} />
        
        {/* Body Shading/Texture */}
        <rect x="11" y="15" width="12" height="12" fill={c.shadow} /> 
        <rect x="12" y="18" width="8" height="8" fill={c.highlight} /> 

        {/* Wing */}
        <rect x="10" y="19" width="6" height="4" fill={c.main} />
        <rect x="9" y="20" width="1" height="2" fill={c.main} />

        {/* Head */}
        <rect x="14" y="8" width="10" height="10" fill={c.shadow} />
        
        {/* Comb (Red thing on top) */}
        <rect x="16" y="6" width="2" height="2" fill="#DC2626" />
        <rect x="18" y="5" width="2" height="3" fill="#DC2626" />
        <rect x="20" y="6" width="2" height="2" fill="#DC2626" />

        {/* Beak */}
        <rect x="24" y="12" width="2" height="2" fill="#F59E0B" />
        
        {/* Wattle (Red thing under beak) */}
        <rect x="22" y="14" width="2" height="2" fill="#DC2626" />

        {/* Eye */}
        <rect x="18" y="10" width="2" height="2" fill="black" />
        <rect x="19" y="10" width="1" height="1" fill="white" /> {/* Sparkle */}
        
        {/* Tail */}
        <rect x="7" y="13" width="3" height="4" fill={c.main} />
        <rect x="6" y="14" width="1" height="2" fill={c.main} />
      </svg>
    </div>
  );
};
