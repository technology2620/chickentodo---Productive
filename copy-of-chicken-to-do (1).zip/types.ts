export interface Task {
  id: string;
  text: string;
  time: string; // HH:MM
  completed: boolean;
}

export type Screen = 'HOME' | 'MENU' | 'NEW_TASK' | 'SETTINGS' | 'CUSTOMIZE' | 'GAME' | 'RESULT';

export type ChickenSkin = 'brownie' | 'generic' | 'bluejay' | 'spicy' | 'lemon';
export type BgTheme = 'beach' | 'park' | 'sky' | 'plains';

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export interface UserStats {
  points: number;
  level: number;
  streak: number;
  daysAlive: number;
  history: Record<string, number>;
  totalTasksCompleted: number;
  unlockedBadges: string[];
}