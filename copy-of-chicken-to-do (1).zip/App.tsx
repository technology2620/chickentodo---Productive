import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { Background } from './components/Background';
import { PixelButton } from './components/PixelButton';
import { Chicken } from './components/Chicken';
import { Boat, Rocket, FriedChicken } from './components/GameAssets';
import { Task, Screen, ChickenSkin, BgTheme, UserStats } from './types';
import { ArrowLeft, Plus, Check, Trash2, Settings, Play, X, Clock } from 'lucide-react';

const App: React.FC = () => {
  const [screen, setScreen] = useState<Screen>('HOME');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTaskText, setNewTaskText] = useState('');
  const [newTaskTime, setNewTaskTime] = useState('09:30');
  
  // Customization
  const [skin, setSkin] = useState<ChickenSkin>('brownie');
  const [theme, setTheme] = useState<BgTheme>('beach');

  // Game State
  const [gameResult, setGameResult] = useState<'WIN' | 'LOSE' | null>(null);

  // Stats
  const [stats, setStats] = useState<UserStats>({
    points: 0,
    level: 1,
    streak: 0,
    daysAlive: 0,
    history: {},
    totalTasksCompleted: 0,
    unlockedBadges: []
  });

  // Load/Save Logic (Simplified for brevity)
  useEffect(() => {
    const s = localStorage.getItem('chicken-stats');
    if (s) setStats(JSON.parse(s));
    
    const t = localStorage.getItem('chicken-tasks');
    if (t) setTasks(JSON.parse(t));
  }, []);

  useEffect(() => {
    localStorage.setItem('chicken-stats', JSON.stringify(stats));
    localStorage.setItem('chicken-tasks', JSON.stringify(tasks));
  }, [stats, tasks]);

  // Handlers
  const addTask = () => {
    if (!newTaskText) return;
    const newTask: Task = {
      id: Date.now().toString(),
      text: newTaskText,
      time: newTaskTime,
      completed: false
    };
    setTasks([...tasks, newTask]);
    setNewTaskText('');
    setScreen('MENU');
  };

  const removeTask = (id: string) => {
      setTasks(tasks.filter(t => t.id !== id));
  }

  const completeTaskInGame = (id: string) => {
      setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: true } : t));
  };

  const finishDay = () => {
      const allCompleted = tasks.length > 0 && tasks.every(t => t.completed);
      
      if (allCompleted) {
          setGameResult('WIN');
          setStats(prev => ({
              ...prev,
              points: prev.points + (tasks.length * 10),
              daysAlive: prev.daysAlive + 1,
              streak: prev.streak + 1
          }));
      } else {
          setGameResult('LOSE');
          setStats(prev => ({
              ...prev,
              streak: 0,
              daysAlive: 0 // Reset days alive on death as per PDF "1st Day Alive" implies streak
          }));
      }
      setScreen('RESULT');
  };

  // --- RENDER SCREENS ---

  const renderHome = () => (
    <div className="flex flex-col items-center justify-between h-full pt-20 pb-32 animate-fade-in z-10 relative">
      <div className="text-center space-y-4">
        <h1 className="text-7xl text-white drop-shadow-[4px_4px_0_rgba(0,0,0,1)] tracking-widest font-bold font-[VT323]">Chicken</h1>
        <h1 className="text-8xl text-[#F4D096] drop-shadow-[4px_4px_0_rgba(0,0,0,1)] tracking-widest font-bold font-[VT323]">To-Do</h1>
      </div>
      
      <div className="w-64">
         <PixelButton onClick={() => setScreen('MENU')}>
            New Day
         </PixelButton>
      </div>
      
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
          <Chicken skin={skin} />
      </div>
    </div>
  );

  const renderMenu = () => (
    <div className="flex flex-col items-center justify-center h-full px-8 space-y-4 w-full max-w-md mx-auto z-10 relative">
      <PixelButton onClick={() => setScreen('NEW_TASK')}>New Task</PixelButton>
      <PixelButton onClick={() => setScreen('SETTINGS')} variant="secondary">Settings</PixelButton>
      <PixelButton onClick={() => setScreen('CUSTOMIZE')} variant="secondary">Customize</PixelButton>
      <div className="h-4" />
      <PixelButton onClick={() => setScreen('GAME')}>START</PixelButton>
      <div className="h-4" />
      <PixelButton onClick={() => setScreen('HOME')} variant="danger">Back</PixelButton>
      
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
          <Chicken skin={skin} />
      </div>
    </div>
  );

  const renderNewTask = () => (
      <div className="flex flex-col h-full w-full max-w-lg mx-auto pt-10 px-4 z-10 relative">
          <div className="bg-[#F4D096] border-4 border-black p-6 rounded-3xl shadow-xl space-y-6">
              <div className="flex justify-between items-center border-b-4 border-black pb-4">
                  <button onClick={() => setScreen('MENU')}><ArrowLeft size={32} /></button>
                  <h2 className="text-4xl font-bold">New Task</h2>
                  <div className="w-8" />
              </div>
              
              <div className="space-y-2">
                  <label className="text-2xl font-bold">Task Name</label>
                  <input 
                    className="w-full bg-white border-4 border-black p-3 text-2xl font-[VT323] rounded-xl"
                    value={newTaskText}
                    onChange={(e) => setNewTaskText(e.target.value)}
                    placeholder="e.g. Ring Bell"
                  />
              </div>

              <div className="space-y-2">
                  <label className="text-2xl font-bold">Time</label>
                  <div className="flex items-center bg-white border-4 border-black p-3 rounded-xl">
                      <Clock className="mr-2" />
                      <input 
                        type="time"
                        className="w-full bg-transparent text-2xl font-[VT323] outline-none"
                        value={newTaskTime}
                        onChange={(e) => setNewTaskTime(e.target.value)}
                      />
                  </div>
              </div>

              <PixelButton onClick={addTask}>Finish</PixelButton>

              {/* Current Tasks List Preview */}
              <div className="mt-4 max-h-40 overflow-y-auto pixel-scrollbar border-t-4 border-black pt-2">
                  <h3 className="text-xl font-bold mb-2">Today's Tasks:</h3>
                  {tasks.map(t => (
                      <div key={t.id} className="flex justify-between items-center bg-white border-2 border-black p-2 mb-2 rounded-lg">
                          <span>{t.time} - {t.text}</span>
                          <button onClick={() => removeTask(t.id)} className="text-red-500"><Trash2 size={16}/></button>
                      </div>
                  ))}
              </div>
          </div>
      </div>
  );

  const renderCustomize = () => (
      <div className="flex flex-col h-full pt-10 px-4 z-10 relative items-center">
          <h2 className="text-6xl text-white drop-shadow-[4px_4px_0_#000] mb-8 font-bold">Customize</h2>
          
          <div className="bg-[#F4D096] border-4 border-black p-4 rounded-3xl w-full max-w-md flex-1 overflow-y-auto pixel-scrollbar">
              <h3 className="text-3xl font-bold mb-4">Skins</h3>
              <div className="grid grid-cols-3 gap-4 mb-8">
                  {(['brownie', 'generic', 'bluejay', 'spicy', 'lemon'] as ChickenSkin[]).map(s => (
                      <div key={s} onClick={() => setSkin(s)} className={`p-2 border-4 rounded-xl cursor-pointer ${skin === s ? 'border-blue-500 bg-white' : 'border-black bg-transparent'}`}>
                          <Chicken skin={s} className="w-full h-auto" />
                          <p className="text-center text-xl capitalize">{s}</p>
                      </div>
                  ))}
              </div>

              <h3 className="text-3xl font-bold mb-4">Backgrounds</h3>
              <div className="space-y-4">
                  {(['beach', 'park', 'sky', 'plains'] as BgTheme[]).map(t => (
                      <button key={t} onClick={() => setTheme(t)} className={`w-full py-4 text-2xl font-bold border-4 rounded-xl capitalize ${theme === t ? 'bg-blue-400 text-white' : 'bg-white text-black'}`}>
                          {t}
                      </button>
                  ))}
              </div>
          </div>
          
          <div className="w-full max-w-md mt-4">
            <PixelButton onClick={() => setScreen('MENU')}>Back</PixelButton>
          </div>
      </div>
  );

  const renderGame = () => {
      const activeTasks = tasks.filter(t => !t.completed);
      
      return (
        <div className="w-full h-full relative z-10">
            {/* HUD */}
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-[#F4D096] border-4 border-black px-6 py-2 rounded-full shadow-lg">
                <span className="text-4xl font-bold">12:00 PM</span>
            </div>

            {/* Game Area */}
            <div className="absolute inset-0 top-20 bottom-32 overflow-hidden">
                {activeTasks.length === 0 && (
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
                         <h2 className="text-5xl text-white drop-shadow-[3px_3px_0_#000] font-bold">Done!</h2>
                    </div>
                )}
                
                {activeTasks.map((task, idx) => (
                    <div 
                        key={task.id} 
                        className="absolute cursor-pointer hover:scale-105 transition-transform"
                        style={{ 
                            top: `${10 + (idx * 15)}%`, 
                            left: idx % 2 === 0 ? '10%' : '50%',
                            width: '140px',
                            height: '80px',
                            animation: `float ${3 + idx}s infinite ease-in-out`
                        }}
                        onClick={() => {
                             if(confirm(`Complete "${task.text}"?`)) completeTaskInGame(task.id);
                        }}
                    >
                        <Boat />
                        <div className="bg-white border-2 border-black px-2 py-1 text-center text-sm font-bold -mt-2 relative z-10 rounded">
                            {task.text}
                        </div>
                    </div>
                ))}
            </div>

            {/* Controls */}
            <div className="absolute bottom-4 w-full px-4 flex justify-between items-end">
                 <button onClick={() => setScreen('MENU')} className="bg-[#EF4444] border-4 border-black p-3 rounded-full text-white shadow-lg">
                    <X size={32} />
                 </button>
                 
                 <div className="flex flex-col items-center">
                    <Chicken skin={skin} />
                 </div>

                 <button onClick={finishDay} className="bg-[#10B981] border-4 border-black p-3 rounded-full text-white shadow-lg">
                    <Check size={32} />
                 </button>
            </div>
            
            <style>{`
                @keyframes float {
                    0% { transform: translateY(0px); }
                    50% { transform: translateY(-10px); }
                    100% { transform: translateY(0px); }
                }
            `}</style>
        </div>
      );
  };

  const renderResult = () => (
      <div className="flex flex-col items-center justify-center h-full z-10 relative px-4 text-center">
          {gameResult === 'WIN' ? (
              <>
                 <h2 className="text-6xl text-white drop-shadow-[4px_4px_0_#000] font-bold mb-8">Day Completed!!</h2>
                 <div className="w-48 h-48 mb-8 animate-bounce">
                     <Rocket />
                     <div className="absolute inset-0 flex items-center justify-center pt-8">
                         <Chicken skin={skin} className="w-16 h-16" />
                     </div>
                 </div>
                 <div className="text-4xl text-white drop-shadow-[2px_2px_0_#000] font-bold">
                     You did<br/>
                     <span className="text-8xl text-yellow-300">{tasks.length}</span><br/>
                     Things today!!
                 </div>
              </>
          ) : (
              <>
                <h2 className="text-5xl text-white drop-shadow-[4px_4px_0_#000] font-bold mb-8">Your chicken was<br/>turned into food...</h2>
                <div className="w-64 h-64 mb-8">
                    <FriedChicken />
                </div>
                <div className="text-3xl text-white drop-shadow-[2px_2px_0_#000] font-bold">
                    Better luck tomorrow...
                </div>
              </>
          )}
          
          <div className="mt-12 w-64">
              <PixelButton onClick={() => setScreen('HOME')}>Finish</PixelButton>
          </div>
      </div>
  );

  return (
    <div className="relative w-full h-screen font-[VT323] overflow-hidden select-none">
      <Background theme={theme} />
      
      {screen === 'HOME' && renderHome()}
      {screen === 'MENU' && renderMenu()}
      {screen === 'NEW_TASK' && renderNewTask()}
      {screen === 'CUSTOMIZE' && renderCustomize()}
      {screen === 'GAME' && renderGame()}
      {screen === 'RESULT' && renderResult()}
      {screen === 'SETTINGS' && (
          <div className="absolute inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
              <div className="bg-[#F4D096] border-4 border-black p-6 rounded-3xl w-full max-w-sm text-center">
                  <h2 className="text-4xl font-bold mb-4">Settings</h2>
                  <p className="text-xl mb-6">Sound, Alarm & Notifications would be configured here in a native app.</p>
                  <PixelButton onClick={() => setScreen('MENU')}>Close</PixelButton>
              </div>
          </div>
      )}
    </div>
  );
};

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);