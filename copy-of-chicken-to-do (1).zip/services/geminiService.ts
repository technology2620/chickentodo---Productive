import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getChickenWisdom = async (context: string): Promise<string> => {
  try {
    const model = ai.models.getGenerativeModel({
        model: "gemini-3-flash-preview",
        systemInstruction: "You are a wise, supportive, and slightly humorous chicken assistant in a pixel-art game. Keep responses short (under 20 words), motivational, and related to completing tasks or starting a new day. Use puns if appropriate (egg, cluck, peck, etc.)."
    });

    const result = await model.generateContent({
      contents: context,
    });
    
    return result.text || "Cluck cluck! You can do it!";
  } catch (error) {
    console.error("Error fetching chicken wisdom:", error);
    return "Keep going! Bock bock!";
  }
};

export const breakdownTask = async (task: string): Promise<string[]> => {
    try {
        const model = ai.models.getGenerativeModel({
            model: "gemini-3-flash-preview",
            systemInstruction: "Break down the provided task into 3 very short, actionable sub-steps. Return only the steps as a JSON array of strings."
        });

        const result = await model.generateContent({
            contents: `Break down this task: ${task}`,
            config: {
                responseMimeType: "application/json"
            }
        });

        const text = result.text;
        if (!text) return [];
        return JSON.parse(text);
    } catch (error) {
        console.error("Error breaking down task:", error);
        return ["Start small", "Keep working", "Finish it"];
    }
}
