import { UserStats, Badge } from '../types';

export const BADGES: Badge[] = [
  { id: 'first_peck', name: 'First Peck', description: 'Complete your first task', icon: '🐣' },
  { id: 'worker_hen', name: 'Worker Hen', description: 'Complete 10 tasks', icon: '🐔' },
  { id: 'early_bird', name: 'Early Bird', description: 'Complete a task before 9 AM', icon: '🌅' },
  { id: 'night_owl', name: 'Night Owl', description: 'Complete a task after 8 PM', icon: '🦉' },
  { id: 'busy_beak', name: 'Busy Beak', description: 'Complete 5 tasks in one day', icon: '💨' },
  { id: 'task_master', name: 'Task Master', description: 'Complete 50 tasks total', icon: '👑' },
];

export const calculateLevel = (points: number) => {
  // Simple curve: Level 1 = 0-49, Level 2 = 50-149, etc.
  return Math.floor(Math.sqrt(points / 10)) + 1;
};

export const getNextLevelThreshold = (currentLevel: number) => {
  // Points needed to reach NEXT level
  return Math.pow(currentLevel, 2) * 10;
};

export const getPointsForCurrentLevel = (currentLevel: number) => {
    return Math.pow(currentLevel - 1, 2) * 10;
}

export const checkBadges = (stats: UserStats, currentTaskTime: Date, dailyCount: number): string[] => {
  const newBadges: string[] = [];
  const hours = currentTaskTime.getHours();

  if (stats.totalTasksCompleted >= 1 && !stats.unlockedBadges.includes('first_peck')) {
    newBadges.push('first_peck');
  }
  if (stats.totalTasksCompleted >= 10 && !stats.unlockedBadges.includes('worker_hen')) {
    newBadges.push('worker_hen');
  }
  if (stats.totalTasksCompleted >= 50 && !stats.unlockedBadges.includes('task_master')) {
    newBadges.push('task_master');
  }
  if (hours < 9 && !stats.unlockedBadges.includes('early_bird')) {
    newBadges.push('early_bird');
  }
  if (hours >= 20 && !stats.unlockedBadges.includes('night_owl')) {
    newBadges.push('night_owl');
  }
  if (dailyCount >= 5 && !stats.unlockedBadges.includes('busy_beak')) {
      newBadges.push('busy_beak');
  }
  
  return newBadges;
};

export const MOCK_LEADERBOARD = [
    { name: 'Cluck Norris', points: 5240 },
    { name: 'Hen Solo', points: 3890 },
    { name: 'Princess Lay-a', points: 2100 },
    { name: 'Kylo Hen', points: 1500 },
    { name: 'Eggbert', points: 800 },
];
